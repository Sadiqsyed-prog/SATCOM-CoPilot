# Space Operations Co-Pilot (SATCOM-CoPilot) 🛰️

**Kaggle 5-Day AI Agents Intensive: Vibe Coding Capstone Project (Freestyle Track)**

An autonomous, multi-agent terminal application for satellite trajectory tracking, orbital pass calculations, and weather-gated observation planning.

## Overview

The **Space Operations Co-Pilot** utilizes a progressive disclosure multi-agent architecture to parse natural language queries, compute exact orbital mechanics using the SGP4 propagation model, check real-time cloud cover, and provide a polished mission briefing to the user.

### Key Features
1. **Natural Language Flight Director**: Robust NLP routing that parses intent, extracts location entities seamlessly, and coordinates sub-agent workflows.
2. **Deterministic Orbital Mechanics (GNC Console)**: Powered by `skyfield` and `sgp4` to fetch live TLE (Two-Line Element) data from CelesTrak and compute precise satellite pass windows, velocity, and altitude.
3. **Weather Gating (Environmental Console)**: Interrogates the Open-Meteo API for real-time and forecasted cloud cover, mapping it to visibility classifications (e.g., `EXCELLENT`, `PARTIAL`, `OBSTRUCTED`). Includes a deterministic fallback pipeline (Rule R-005) for network resiliency.
4. **Aerospace Typer/Rich UI**: A gorgeous, consumer-friendly command-line interface featuring dynamic loading spinners and vibrant, color-coded tracking tables.
5. **Spec-Driven BDD Architecture**: Governed by strict Gherkin/Behave test suites ensuring zero hallucinated orbital data and perfect input guardrails.

## Installation

Ensure you have Python 3.10+ installed.

```bash
# Clone or unzip the repository
cd SATTELITE_Tracking

# Install dependencies
pip install -r requirements.txt
```

*(Note for Windows users: You may want to run `$env:PYTHONUTF8=1` in PowerShell prior to launching to ensure full emoji and UI rendering support.)*

## Usage

You can launch the Co-Pilot in an interactive shell or pass a single query directly.

**Interactive Mode:**
```bash
python -m src.main
```

**Single Query Examples:**
```bash
python -m src.main "When can I see the ISS from Bengaluru?"
python -m src.main "where is the ISS right now?"
python -m src.main "ISS pass over Hyderabad and what is its condition"
```

## Agent Architecture
- **Flight Director (FD) Agent**: Parses intent, handles Geocoding fallbacks, and formats aggregated reports.
- **GNC Console Agent**: Calculates orbital kinematics (`LIVE_TELEMETRY` & `TRACK_PASS`).
- **Weather & COMM Console Agent**: Assesses atmospheric obstruction for visual observation.
- **QA / Evaluation Agent (Planned)**: Scheduled for Kaggle Phase 2 (Hallucination detection & Rubric scoring).

## Testing

This project utilizes `behave` for strict BDD validation.

```bash
behave features/
```
*(All 16 scenarios and 152 steps pass deterministically.)*

---
*Developed for the Kaggle AI Agents Intensive Capstone.*
